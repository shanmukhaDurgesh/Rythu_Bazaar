// For Dev Environment use this property


// import {environmentprod} from 'src/environments/environment.prod'; //For Producation Environment use this property
import { HttpHeaders } from '@angular/common/http';
import { environment } from './../../../environments/environment';
import Swal from 'sweetalert2';


export class AppConfig {
    public static httpOptions = {
        headers: new HttpHeaders({
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'POST, GET, PATCH, OPTIONS, DELETE',
            'Access-Control-Allow-Headers': 'Origin, X-Requested-With, Content-Type, Accept',
            'sessionid': localStorage.session_id
        })
    };

    public static ACCESS_TOKEN_PATH = '/oauth/token';
    public static ACCESS_TOKEN = 'access_token';


    public static BASE_URL = environment.baseURL;  // For Dev Environment use this property




    public static GRID_PAGE_INFO = {
        'initpageSize': 100,
        'pageOptions': [100, 150, 200]
    }

    public static  alertDialogue = Swal.mixin({
        customClass: {
          confirmButton: 'btn btn-success',
          cancelButton: 'btn btn-danger'
        },
        buttonsStyling: false
      })

      public static PAGE_ACTIONS = {
        create: 'CREATE',
        view: 'VIEW',
        delete: 'DELETE',
        edit: 'EDIT',
     }


}
