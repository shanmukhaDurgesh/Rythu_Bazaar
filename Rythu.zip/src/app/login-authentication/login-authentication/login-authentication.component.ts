import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-authentication',
  templateUrl: './login-authentication.component.html',
  styleUrls: ['./login-authentication.component.scss']
})
export class LoginAuthenticationComponent implements OnInit {

  userName: string;
  userPassword: string;
  constructor(private router: Router) { }

  ngOnInit() {
  }

  onLogin(loginForm){
   if(loginForm.valid){
     localStorage.setItem('isAuthorized', 'true');
     this.router.navigate(['/m1'])
   }else{
    localStorage.setItem('isAuthorized', 'false')
   }
  }
}
