import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-m2',
  templateUrl: './m2.component.html',
  styleUrls: ['./m2.component.scss']
})
export class M2Component implements OnInit {

  constructor() { }
  userName;
  ngOnInit() {
  }

}
