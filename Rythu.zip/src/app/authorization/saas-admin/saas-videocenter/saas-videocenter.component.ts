import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-saas-videocenter',
  templateUrl: './saas-videocenter.component.html',
  styleUrls: ['./saas-videocenter.component.scss']
})
export class SaasVideocenterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
