export class User {
  name: string;
  userName: string;
  zipCode: string;
  website: string;
  id: string;
  suite: string;
}
