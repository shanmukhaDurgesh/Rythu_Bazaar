export class Company {
    name : string;
    addressOne : string;
    addressTwo : string;
    addressThree : string;
    city : string;
    state : string;
    country : string;
    zipCode : Number
}