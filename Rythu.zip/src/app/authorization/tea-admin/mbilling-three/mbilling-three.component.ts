import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mbilling-three',
  templateUrl: './mbilling-three.component.html',
  styleUrls: ['./mbilling-three.component.scss']
})
export class MbillingThreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
