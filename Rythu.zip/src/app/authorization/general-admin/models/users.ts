export class Users {
    name : string;
    lastName : string;
    email : string;
    phone : string;
    role : string;
    academy : string;
    internal : boolean;
    zipCode : Number;
    int : Array<object>;
}