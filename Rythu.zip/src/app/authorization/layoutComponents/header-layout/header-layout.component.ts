import { Component, OnInit, Input } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-header-layout',
  templateUrl: './header-layout.component.html',
  styleUrls: ['./header-layout.component.scss']
})
export class HeaderLayoutComponent implements OnInit {

  public pushRightClass: string;
  loggedUser = localStorage.getItem('loggedUserName');
  @Input('sidebar') sidebar;
  loggedUserPermissions: any;
  loggedUserDetails: any;
  loggedUserTitleLetters: string = '';
  public prfBool = false; 
  loggedUserPrf : string;

  
  constructor( public router: Router) {

      this.router.events.subscribe(val => {
          if (
              val instanceof NavigationEnd &&
              window.innerWidth <= 992 &&
              this.isToggled()
          ) {
              this.toggleSidebar();
          }
      });
  }

  ngOnInit() {
      this.loggedUserPrf = 'ShanmukhDurgesh18@gmail.com'
      
      this.pushRightClass = 'push-right';
  }
  userDropDown(){
    this.prfBool = !this.prfBool; 
  }
  isToggled(): boolean {
      const dom: Element = document.querySelector('body');
      return dom.classList.contains(this.pushRightClass);
  }

  toggleSidebar() {
      const dom: any = document.querySelector('body');
      dom.classList.toggle(this.pushRightClass);
  }

  rltAndLtr() {
      const dom: any = document.querySelector('body');
      dom.classList.toggle('rtl');
  }

}
