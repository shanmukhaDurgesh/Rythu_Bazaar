import { Component, Output, EventEmitter, OnInit, Inject  } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import menu from './../../../_files/menu.json'

@Component({
  selector: 'app-left-nav-menu',
  templateUrl: './left-nav-menu.component.html',
  styleUrls: ['./left-nav-menu.component.scss']
})
export class LeftNavMenuComponent implements OnInit {
    isActive: boolean;
    collapsed: boolean;
    showMenu: string;
    showSubMenu: string;
    pushRightClass: string;
    showSystemMenu: string;
    sideMenu: any;
    defaultPagePermissions: any = [];
    loggedUserPermissions: any;
    loggedUserDetails: any = {};
    @Output() collapsedEvent = new EventEmitter<boolean>();
    userScreens: any;
    showJobMenu: string;
    showTeaAdminMenu: string;
    selectedMenu : string;
    // sideMenuList :any[] = [];
    mmenu: any[] = [];
    smenu: any[] = [];
    sbMenu: any;
    sdMainMenu: any[] = [];
    sideMenuList : any[] = menu.Module



    constructor(public router: Router) {
        this.router.events.subscribe(val => {
            if (
                val instanceof NavigationEnd &&
                window.innerWidth <= 992 &&
                this.isToggled()
            ) {
                this.toggleSidebar();
            }
        });
        if (localStorage.getItem('loggedUserPermissions')) {
            this.buildPermissions();
        }

    }
    ngOnInit() {
        this.sideMenuList[0].Menus.forEach(e => {           
            this.sbMenu = e.subMenus
            let reqObj = {
                "menuItemName" : e.menName,
                "menuUrl" : e.url,
                "permissions" : e.permissions,
                "subMenus":this.sbMenu || []
            }
            this.mmenu.push(reqObj)
        })
        console.log(this.mmenu);
        
        this.isActive = false;
        this.collapsed = false;
        this.showMenu = '';
        this.showSubMenu = '';
        this.pushRightClass = 'push-right';
        this.toggleExpanded();
        this.addExpandClass('pages')
    }
    buildPermissions() {
        // let temp = JSON.parse(this.encryDecryService.get('perm', localStorage.getItem('loggedUserPermissions')));
        // this.loggedUserPermissions = temp.permissions.permissionDetails;
        // this.loggedUserDetails = temp;
      
    //    console.log('lside bar ency', temp)
    }


    eventCalled() {
        this.isActive = !this.isActive;
    }

    addExpandClass(element: any) {
        this.collapsed = false
        this.collapsedEvent.emit(this.collapsed);
        this.selectedMenu = element
        }
        redirectTo(data){
            this.router.navigate([data.url,'hii'])
        }
    toggleCollapsed() {
        this.collapsed = false;
        this.collapsedEvent.emit(this.collapsed);
        //this.removeExpandClass();
    }

    removeExpandClass() {
        if ('Administration' === this.selectedMenu) {
            this.selectedMenu = '0';
        }
    }

    toggleExpanded() {
        this.collapsed = false;
        this.collapsedEvent.emit(this.collapsed);
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    rltAndLtr() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle('rtl');
    }

    changeLang(language: string) {
        // this.translate.use(language);
    }

    onLoggedout() {
        localStorage.removeItem('isLoggedin');
    }


    toggleSideMenu() {
        if (this.collapsed) {
            //this.toggleExpanded();
            this.collapsed = false;
            this.collapsedEvent.emit(this.collapsed);

        } else {
            //this.toggleCollapsed();
            this.collapsed = true;
            this.collapsedEvent.emit(this.collapsed);
            this.removeExpandClass();
        }
    }


}
