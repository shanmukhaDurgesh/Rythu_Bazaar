export class AcademyManagement {
    name : string;
    email : string;
    phone : string;
    addressOne : string;
    addressTwo : string;
    city : string;
    state : string
    zipCode : Number
    country : string
    subscription : string;
    affiliates : boolean;
}